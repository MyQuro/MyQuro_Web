ALTER TABLE "restaurants" ADD COLUMN "request_status" text DEFAULT 'PENDING' NOT NULL;--> statement-breakpoint
ALTER TABLE "restaurants" ADD COLUMN "requested_at" timestamp DEFAULT now() NOT NULL;--> statement-breakpoint
ALTER TABLE "restaurants" ADD COLUMN "reviewed_at" timestamp;--> statement-breakpoint
ALTER TABLE "restaurants" ADD COLUMN "reviewed_by_admin_id" text;--> statement-breakpoint
ALTER TABLE "restaurants" ADD COLUMN "admin_remark" text;--> statement-breakpoint
ALTER TABLE "restaurants" ADD CONSTRAINT "restaurants_request_status_check" CHECK ("restaurants"."request_status" IN ('PENDING', 'APPROVED', 'REJECTED'));