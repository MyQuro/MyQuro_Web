ALTER TABLE "profiles" ADD COLUMN "phone_number" text;--> statement-breakpoint
ALTER TABLE "restaurants" ADD COLUMN "default_gst_percentage" numeric(5, 2);