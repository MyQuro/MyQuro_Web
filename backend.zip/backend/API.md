# API Documentation

This document outlines the API endpoints available in the MyQuro backend.

## Overview

MyQuro is a restaurant management and ordering system. The API provides endpoints for:

- User authentication and profile management
- Restaurant registration and management
- Menu creation and management
- Table and QR code management for contactless ordering
- Order placement and management
- Billing and payment processing
- Staff management
- Admin approval workflows

## API Flow

### Customer Journey

1. **Authentication**: User signs up/logs in via `/api/auth`
2. **Profile Setup**: User creates profile via `/api/profile`
3. **Browse Restaurants**: User browses restaurants via `/api/restaurants`
4. **Scan QR**: User scans table QR code via `/api/qr/scan/:qrToken` (creates session)
5. **View Menu**: User views restaurant menu via `/api/menus/:restaurantId/menu`
6. **Place Order**: User places order via `/api/orders/make-order`
7. **View Orders**: User views their orders via `/api/orders/:tableSessionId`
8. **Payment**: User pays via `/api/payments/:tableSessionId/pay`

### Restaurant Owner Journey

1. **Authentication**: Owner signs up/logs in
2. **Apply for Restaurant**: Owner applies via `/api/restaurants/apply`
3. **Wait for Approval**: Admin approves via `/api/admin/restaurants/:requestId/approve`
4. **Manage Restaurant**: Owner manages restaurant details
5. **Create Menu**: Owner creates menu via `/api/menus` endpoints
6. **Manage Tables**: Owner creates tables and QR codes via `/api/restaurant-tables`
7. **Invite Staff**: Owner invites staff via `/api/restaurants/:restaurantId/invite-staff`
8. **Manage Orders**: Staff views and updates orders via `/api/orders`

### Staff Journey

1. **Receive Invite**: Staff receives email invite
2. **View Invite**: Staff views invite details via `/api/staff-requests/view-invite/:inviteToken`
3. **Accept Invite**: Staff accepts via `/api/staff-requests/:inviteToken/accept-invite`
4. **Manage Orders**: Staff updates order status via `/api/orders/:orderId/status`

## Base URL

`http://localhost:3000` (or your configured `BACKEND_URL`)

## Authentication

Authentication is handled via **Better Auth**.

- **Base Path**: `/api/auth`
- **Common Endpoints**:
  - `POST /api/auth/sign-in/email`
  - `POST /api/auth/sign-up/email`
  - `POST /api/auth/sign-out`
  - `GET /api/auth/session`
  - (See Better Auth documentation for full list)

---

## Restaurants

### Base Path: `/api/restaurants`

#### 1. Get All Restaurants

**GET** `/`

- **Description**: Fetch a list of all restaurants.
- **Auth**: Public.
- **Response**:

  ```json
  {
    "restaurants": [
      {
        "id": "string",
        "restaurantName": "string",
        "restaurantType": "string",
        "restaurantAddress": "string",
        "city": "string",
        "state": "string",
        "postalCode": "number",
        "phoneNumber": "number",
        "email": "string",
        "cuisine": ["string"],
        "rating": "number",
        "ratingCount": "number",
        "restaurantStatus": "active | inactive | suspended",
        "createdAt": "timestamp",
        "updatedAt": "timestamp"
      }
    ]
  }
  ```



#### 2. Get Restaurant Details by ID

**GET** `/:id`

- **Description**: Fetch details of a specific restaurant by its ID.
- **Auth**: Public.
- **Response**:

  ```json
  {
    "restaurant": {
      "id": "string",
      "restaurantName": "string",
      "restaurantType": "string",
      "restaurantAddress": "string",
      "city": "string",
      "state": "string",
      "postalCode": "number",
      "phoneNumber": "number",
      "email": "string",
      "cuisine": ["string"],
      "rating": "number",
      "ratingCount": "number",
      "restaurantStatus": "active | inactive | suspended",
      "createdAt": "timestamp",
      "updatedAt": "timestamp"
    }
  }
  ```



#### 3. Apply for a Restaurant

**POST** `/apply`

- **Description**: Submit a new restaurant application.
- **Auth**: Required (User role must not be `restaurant_owner` or `admin`).
- **Body**:

  ```json
  {
    "restaurantName": "string",
    "restaurantType": "string",
    "restaurantAddress": "string",
    "city": "string",
    "state": "string",
    "postalCode": "string",
    "phoneNumber": "string",
    "email": "string",
    "description": "string",
    "gstNumber": "string",
    "fssaiLicenseNumber": "string",
    "defaultGstPercentage": number
  }
  ```

#### 4. View Application Status

**GET** `/view-request`

- **Description**: View the status of the user's most recent restaurant application.
- **Auth**: Required.

#### 5. Get My Restaurant

**GET** `/my-restaurant`

- **Description**: Get details of the restaurant owned by the authenticated user.
- **Auth**: Required (Role: `restaurant`).

#### 7. Get Restaurant by User ID

**GET** `/:userId/id`

- **Description**: Get restaurant details by the owner's user ID.
- **Auth**: Required.

#### 8. Check if User Has Approved Restaurant

**GET** `/has-approved`

- **Description**: Check if the authenticated user has an approved restaurant.
- **Auth**: Required.
- **Response**: `{ "hasApproved": boolean }`

#### 9. Invite Staff

**POST** `/:restaurantId/invite-staff`

- **Description**: Send an email invitation to a user to join the restaurant staff.
- **Auth**: Required (Owner).
- **Body**:

  ```json
  {
    "invitedEmail": "string",
    "role": "string" // e.g., "manager", "staff"
  }
  ```

#### 7. List Staff Invites

**GET** `/:restaurantId/staff-invites`

- **Description**: Get a list of all pending and past staff invites for a specific restaurant.
- **Auth**: Required (Owner).

#### 8. List Staff

**GET** `/:restaurantId/staff`

- **Description**: Get a list of all active staff members for a specific restaurant.
- **Auth**: Required (Owner/Manager).

---

## Restaurant Tables

### Base Path: `/api/restaurant-tables`

#### 1. Create Table

**POST** `/:restaurantId/tables/create`

- **Description**: Create a new table for a restaurant.
- **Auth**: Required (Owner/Manager).
- **Body**:

  ```json
  {
    "tableNumber": number,
    "capacity": number
  }
  ```

#### 2. List Tables

**GET** `/:restaurantId/tables`

- **Description**: Get all tables for a specific restaurant.
- **Auth**: Required (Owner/Manager).

#### 3. Update Table

**PATCH** `/tables/:tableId`

- **Description**: Update table details.
- **Auth**: Required (Owner/Manager).
- **Body**:

  ```json
  {
    "tableNumber": number, // optional
    "capacity": number,    // optional
    "liveStatus": "string", // optional
    "isActive": boolean    // optional
  }
  ```

#### 4. Delete Table

**DELETE** `/tables/:tableId`

- **Description**: Soft delete a table.
- **Auth**: Required (Owner/Manager).

#### 5. Generate QR Code

**POST** `/tables/:tableId/qrcode`

- **Description**: Generate a new QR code for a table.
- **Auth**: Required (Owner/Manager).
- **Response**: Returns `qrToken`, `scanUrl`, and `qrImageBase64`.

#### 6. Get Table Session

**GET** `/table-session/:sessionId`

- **Description**: Get details of a specific table session.
- **Auth**: Required (Owner/Manager).

#### 7. Close Table Session

**PATCH** `/table-session/:sessionId/close`

- **Description**: Close an active table session.
- **Auth**: Required (Owner/Manager).

---

## Menus

### Base Path: `/api/menus`

#### 1. Create Category

**POST** `/:restaurantId/menu/categories`

- **Description**: Create a new menu category.
- **Auth**: Required (Owner/Manager).
- **Body**:

  ```json
  {
    "name": "string",
    "description": "string",
    "display_order": number
  }
  ```

#### 2. Create Menu Item

**POST** `/:restaurantId/menu/items`

- **Description**: Create a new menu item under a category.
- **Auth**: Required (Owner/Manager).
- **Body**:

  ```json
  {
    "name": "string",
    "description": "string",
    "categoryId": "string"
  }
  ```

#### 3. Create Item Variant

**POST** `/:restaurantId/menu/items/:itemId/variants`

- **Description**: Add a variant (e.g., size, flavor) to a menu item.
- **Auth**: Required (Owner/Manager).
- **Body**:

  ```json
  {
    "name": "string",
    "price": number,
    "additionalInfo": {
      "foodType": "string",
      "portionSize": "string"
    }
  }
  ```

#### 4. Get Public Menu

**GET** `/:restaurantId/menu`

- **Description**: Get the public-facing menu for a restaurant (only active items).
- **Auth**: Public.

#### 5. Get Management Menu

**GET** `/:restaurantId/menu/manage`

- **Description**: Get the full menu for management (includes inactive items).
- **Auth**: Required (Owner/Manager).

#### 6. Update/Deactivate Operations

- **PATCH** `/:restaurantId/menu/categories/:categoryId/deactivate`
- **PATCH** `/:restaurantId/menu/items/:itemId/update`
- **PATCH** `/:restaurantId/menu/items/:itemId/deactivate`
- **PATCH** `/:restaurantId/menu/items/:itemId/variants/:variantId/update`
- **PATCH** `/:restaurantId/menu/items/:itemId/variants/:variantId/deactivate`
- **PATCH** `/:restaurantId/menu/categories/reorder`

---

## QR Scanning

### Base Path: `/api/qr`

#### 1. Scan QR

**GET** `/scan/:qrToken`

- **Description**: Scans a table QR code. If valid, redirects to the client menu URL with a session ID. Creates a new session if one doesn't exist.

---

## Staff Requests

### Base Path: `/api/staff-requests`

#### 1. View Invite

**GET** `/view-invite/:inviteToken`

- **Description**: View details of a staff invitation.
- **Auth**: Required.

#### 2. Accept Invite

**POST** `/:inviteToken/accept-invite`

- **Description**: Accept a staff invitation to join a restaurant.
- **Auth**: Required.

#### 4. Decline Invite

**POST** `/:inviteToken/decline-invite`

- **Description**: Decline a staff invitation.
- **Auth**: Required.

#### 5. My Invites

**GET** `/my-invites`

- **Description**: List all invites sent to the current user's email.
- **Auth**: Required.

---

## Admin

### Base Path: `/api/admin`

#### 1. List Pending Requests

**GET** `/restaurants/requests`

- **Description**: List all pending restaurant approval requests.
- **Auth**: Required (Admin only).

#### 2. Approve Request

**POST** `/restaurants/:requestId/approve`

- **Description**: Approve a restaurant request.
- **Auth**: Required (Admin only).

#### 3. Reject Request

**POST** `/restaurants/:requestId/reject`

- **Description**: Reject a restaurant request.
- **Auth**: Required (Admin only).
- **Body**:

  ```json
  {
    "adminRemark": "string"
  }
  ```

---

## Orders

### Base Path: `/api/orders`

#### 1. Make Order

**POST** `/make-order`

- **Description**: Place a new order for a specific table session.
- **Auth**: Required (Customer or Staff).
- **Body**:

  ```json
  {
    "tableSessionId": "string",
    "notes": "string", // optional
    "items": [
      {
        "menuItemId": "string",
        "menuItemVariantId": "string",
        "quantity": number,
        "itemNotes": "string" // optional
      }
    ]
  }
  ```

#### 2. Get Orders

**GET** `/:tableSessionId`

- **Description**: Get all orders for a specific table session.
- **Auth**: Required (Customer or Staff).

#### 3. Cancel Order

**PATCH** `/:orderId/cancel`

- **Description**: Cancel a placed order (if not yet served/preparing).
- **Auth**: Required (Customer or Staff).

#### 4. Update Order Items

**PATCH** `/:orderId/items/update`

- **Description**: Add, update, or remove items from an existing order.
- **Auth**: Required (Customer or Staff).
- **Body**:

  ```json
  {
    "items": [
      {
        "action": "add" | "update" | "remove",
        "orderItemId": "string", // Required for update/remove
        "menuItemId": "string", // Required for add
        "menuItemVariantId": "string", // Required for add
        "quantity": number,
        "itemNotes": "string" // optional
      }
    ]
  }
  ```

#### 5. Update Order Status

**PATCH** `/:orderId/status`

- **Description**: Update the status of an order.
- **Auth**: Required (Restaurant Staff).
- **Body**:

  ```json
  {
    "status": "placed" | "preparing" | "served" | "cancelled"
  }
  ```

#### 6. Get User Orders

**GET** `/:userId/user-orders`

- **Description**: Get all orders placed by a specific user.
- **Auth**: Required.

#### 7. Get Restaurant Orders

**GET** `/:restaurantId/restaurant-orders`

- **Description**: Get all orders for a specific restaurant.
- **Auth**: Required (Restaurant Staff).

---

## Billing

### Base Path: `/api/billing`

#### 1. Get Total Amount

**GET** `/:tableSessionId/total`

- **Description**: Get the current total billing amount for a session (sum of served items).
- **Auth**: Required.
- **Response**: Returns `totalAmount` in paise.

#### 2. Get Final Amount

**GET** `/:tableSessionId/final-amount`

- **Description**: Get the final amount calculation including discounts and taxes.
- **Auth**: Required.
- **Query Params**:
  - `discountPercentage`: number
  - `taxRate`: number
- **Response**: Returns `finalAmount` in paise.

#### 3. Generate Bill

**POST** `/:tableSessionId/generate-bill`

- **Description**: Generate and freeze the final bill for a session.
- **Auth**: Required.
- **Body**:

  ```json
  {
    "discountPercentage": number,
    "taxRate": number
  }
  ```

- **Response**: Returns `billingDetails` object.

---

## Payments

### Base Path: `/api/payments`

#### 1. Record Payment

**POST** `/:tableSessionId/pay`

- **Description**: Record a payment for a table session.
- **Auth**: Required.
- **Body**:

  ```json
  {
    "amount": number, // in paise
    "method": "string",
    "referenceNumber": "string" // optional
  }
  ```

---

## Protected

### Base Path: `/api/protected`

#### 1. Dashboard

**GET** `/dashboard`

- **Description**: Check authentication status.
- **Auth**: Required.
