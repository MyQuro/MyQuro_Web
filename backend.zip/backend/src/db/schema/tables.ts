import {
  pgTable,
  text,
  timestamp,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { restaurants } from "./restaurants";

export const tables = pgTable("tables", {
  id: text("id").notNull().primaryKey(),
  restaurantId: text("restaurant_id")
    .notNull()
    .references(() => restaurants.id, { onDelete: "cascade" }),

  tableNumber: text("table_number").notNull().unique(),
  capacity: integer("capacity").notNull(),

  liveStatus: text("live_status")
    .notNull()
    .default("available")
    .$type<"available" | "occupied" | "reserved">(),
  isActive: boolean("is_active").notNull().default(true),

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
