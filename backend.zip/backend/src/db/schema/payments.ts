import {
  pgTable,
  text,
  boolean,
  timestamp,
  integer,
} from "drizzle-orm/pg-core";
import { tableSession } from "./table-session";
import { restaurants } from "./restaurants";
import { authUsers } from "./auth-users";

export const payments = pgTable("payments", {
  id: text("id").notNull().primaryKey(),

  // ✅ ALWAYS FK TO table_session PRIMARY KEY
  tableSessionId: text("table_session_id")
    .notNull()
    .references(() => tableSession.id, { onDelete: "cascade" }),

  // ✅ FK DIRECTLY TO restaurants PRIMARY KEY (NOT via table_session)
  restaurantId: text("restaurant_id")
    .notNull()
    .references(() => restaurants.id, { onDelete: "cascade" }),

  // ✅ SAFE MONEY (Rupees with exact precision)
  amount: integer("amount").notNull(),

  // ✅ CONTROLLED PAYMENT METHOD
  method: text("method")
    .notNull()
    .$type<"cash" | "upi" | "card" | "bank" | "gateway">(),

  // ✅ PAYMENT STATE (NOT A BOOLEAN)
  status: text("status")
    .notNull()
    .$type<"pending" | "success" | "failed" | "refunded">(),

  // ✅ UPI / Gateway / Manual Reference
  referenceNumber: text("reference_number"),

  paidByUserId: text("paid_by_user_id").references(() => authUsers.id),

  // ✅ REFUND SUPPORT FOR LATER
  isRefund: boolean("is_refund").default(false),

  // ✅ PROPER TIME TRACKING
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
