import { pgTable, integer, text, timestamp } from "drizzle-orm/pg-core";
import { restaurants } from "./restaurants";
import { tableSession } from "./table-session";
import { tables } from "./tables";
import { authUsers } from "./auth-users";

export const orders = pgTable("orders", {
  id: text("id").notNull().unique().primaryKey(),
  tableSessionId: text("table_session_id")
    .notNull()
    .references(() => tableSession.id, { onDelete: "cascade" }),
  restaurantId: text("restaurant_id")
    .notNull()
    .references(() => restaurants.id, { onDelete: "cascade" }),
  tableId: text("table_id")
    .notNull()
    .references(() => tables.id, { onDelete: "cascade" }),
  placedByUserId: text("placed_by_user_id").references(() => authUsers.id),
  notes: text("notes"),
  status: text("status")
    .notNull()
    .default("placed")
    .$type<"placed" | "preparing" | "served" | "cancelled">(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
