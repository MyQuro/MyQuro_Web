import { db } from "../db/db";
import { and, eq } from "drizzle-orm";
import { tableSession } from "../db/schema/table-session";
import { orderItems } from "../db/schema/order-items";

export async function totalBillingAmount(
  tableSessionId: string
): Promise<number> {
  const session = await db
    .select()
    .from(tableSession)
    .where(eq(tableSession.id, tableSessionId))
    .limit(1);

  if (session.length === 0) {
    throw new Error("Table session not found");
  }

  if (session[0].status === "cancelled") {
    throw new Error("Cannot bill a cancelled session");
  }

  // ✅ Optimized: Removed unnecessary join with 'orders' table
  // orderItems already has tableSessionId
  const sessionOrders = await db
    .select({
      quantity: orderItems.quantity,
      unitPrice: orderItems.unitPrice,
    })
    .from(orderItems)
    .where(
      and(
        eq(orderItems.tableSessionId, tableSessionId),
        eq(orderItems.status, "served")
      )
    );

  let totalAmount = 0;
  for (const item of sessionOrders) {
    totalAmount += item.unitPrice * item.quantity;
  }

  return totalAmount; // ✅ paise
}

export async function finalAmount(
  tableSessionId: string,
  amount: number, // paise
  discountPercentage: number,
  taxRate: number
): Promise<number> {
  const session = await db
    .select()
    .from(tableSession)
    .where(eq(tableSession.id, tableSessionId))
    .limit(1);

  if (session.length === 0) {
    throw new Error("Table session not found");
  }

  if (session[0].status === "cancelled") {
    throw new Error("Cannot bill a cancelled session");
  }

  const discountAmount = calculateDiscount(amount, discountPercentage);
  const taxableAmount = calculateTaxableBase(amount, discountAmount);
  const taxAmount = calculateGST(taxableAmount, taxRate);
  const finalAmt = calculateGrandTotal(taxableAmount, taxAmount);

  return finalAmt;
}

// Helper functions for billing calculations
export function calculateSubtotal(
  items: Array<{ unitPrice: number; quantity: number }>
): number {
  return items.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
}

export function calculateDiscount(
  subtotal: number,
  discountPercentage: number
): number {
  // ✅ Calculate percentage: (amount * percentage) / 100
  // Using Math.floor to keep it an integer (paise)
  return Math.floor((subtotal * discountPercentage) / 100);
}

export function calculateTaxableBase(
  subtotal: number,
  discountAmount: number
): number {
  return subtotal - discountAmount;
}

export function calculateGST(
  taxableBase: number,
  gstPercentage: number
): number {
  // ✅ Calculate percentage: (amount * percentage) / 100
  // Using Math.floor to keep it an integer (paise)
  return Math.floor((taxableBase * gstPercentage) / 100);
}

export function calculateGrandTotal(
  taxableBase: number,
  taxAmount: number
): number {
  return taxableBase + taxAmount;
}
