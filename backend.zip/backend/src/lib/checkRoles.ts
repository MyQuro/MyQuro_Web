import { db } from "../db/db.ts";
import { restaurants } from "../db/schema/restaurants.js";
import { restaurantManagers } from "../db/schema/restaurant-managers.ts";
import { and, eq } from "drizzle-orm";
import { authUsers } from "../db/schema/auth-users.ts";

export async function isRestaurantOwnerOrManager(
  userId: string,
  restaurantId: string
): Promise<boolean> {
  try {
    // Check if the user is the owner of the restaurant
    const isOwner = await db
      .select()
      .from(restaurants)
      .where(
        and(eq(restaurants.id, restaurantId), eq(restaurants.ownerId, userId))
      )
      .limit(1);

    if (isOwner.length > 0) {
      return true;
    }

    // Check if the user is an active manager of the restaurant
    const isManager = await db
      .select()
      .from(restaurantManagers)
      .where(
        and(
          eq(restaurantManagers.userId, userId),
          eq(restaurantManagers.restaurantId, restaurantId),
          eq(restaurantManagers.status, "active") // Ensure the manager is active
        )
      )
      .limit(1);

    return isManager.length > 0;
  } catch (error) {
    console.error("Error in isRestaurantOwnerOrManager:", error);
    return false; // Return false if an error occurs
  }
}

export async function isRestaurantOwner(
  userId: string,
  restaurantId: string
): Promise<boolean> {
  // This function can be expanded as needed
  try {
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(
        and(eq(restaurants.id, restaurantId), eq(restaurants.ownerId, userId))
      )
      .limit(1);

    return restaurant.length > 0;
  } catch (error) {
    console.error("Error in checkRestaurantOwner:", error);
    return false;
  }
}

export async function isRestaurantStaff(
  userId: string,
  restaurantId: string
): Promise<boolean> {
  // This function can be expanded as needed
  try {
    const staff = await db
      .select()
      .from(restaurantManagers)
      .where(
        and(
          eq(restaurantManagers.userId, userId),
          eq(restaurantManagers.restaurantId, restaurantId),
          eq(restaurantManagers.status, "active"),
          eq(restaurantManagers.role, "staff")
        )
      )
      .limit(1);

    return staff.length > 0;
  } catch (error) {
    console.error("Error in checkRestaurantStaff:", error);
    return false;
  }
}

export async function isAdmin(userId: string): Promise<boolean> {
  try {
    const user = await db
      .select()
      .from(authUsers)
      .where(and(eq(authUsers.id, userId), eq(authUsers.role, "admin")))
      .limit(1);

    return user.length > 0;
  } catch (error) {
    console.error("Error in isAdmin:", error);
    return false;
  }
}
