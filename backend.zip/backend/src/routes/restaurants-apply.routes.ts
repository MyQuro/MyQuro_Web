import { Router } from "express";
import { db } from "../db/db";
import { restaurants } from "../db/schema/restaurants";
import { restaurantRequests } from "../db/schema/restaurant-requests";
import { authUsers } from "../db/schema/auth-users";
import { eq, and, desc } from "drizzle-orm";
import { nanoid } from "nanoid";
import { requireAuth } from "../auth/requireAuth"; // <-- import the middleware
import { isRestaurantOwner } from "../lib/checkRoles";

const router = Router();

/**
 * POST /api/restaurants/apply
 */

// 1. ONLY AUTHENTICATED USERS CAN APPLY
router.post("/apply", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    // 2. ROLE CHECK
    if (user.role === "restaurant_owner") {
      return res
        .status(403)
        .json({ message: "accounts related to restaurants cannot apply" });
    } else if (user.role === "admin") {
      return res
        .status(401)
        .json({ message: "Pay Attention you are being watched" });
    }

    // 3. EXISTING PENDING REQUEST CHECK
    const existingRows = await db
      .select()
      .from(restaurantRequests)
      .where(
        and(
          eq(restaurantRequests.userId, user.id),
          eq(
            restaurantRequests.requestStatus,
            "PENDING" as (typeof restaurantRequests.$inferSelect)["requestStatus"]
          )
        )
      )
      .limit(1);
    const existingRequest = existingRows[0];

    if (existingRequest) {
      return res.status(400).json({
        message: "You already have a restaurant under review",
      });
    }

    // 4. VALIDATE INPUT (BARE MINIMUM)
    const {
      restaurantName,
      restaurantType,
      restaurantAddress,
      city,
      state,
      postalCode,
      phoneNumber,
      email,
      description,
      gstNumber,
      fssaiLicenseNumber,
      defaultGstPercentage,
    } = req.body;

    if (
      !restaurantName ||
      !restaurantType ||
      !restaurantAddress ||
      !city ||
      !state ||
      !postalCode ||
      !phoneNumber ||
      !email ||
      !fssaiLicenseNumber
    ) {
      return res.status(400).json({
        message: "Missing required restaurant details",
      });
    }

    // 5. REMOVE OPERATION
    const restaurantId = nanoid();
    const requestId = nanoid();

    // A. CREATE RESTAURANT
    await db.insert(restaurants).values({
      id: restaurantId,
      ownerId: user.id,
      restaurantName,
      restaurantType,
      restaurantAddress,
      city,
      state,
      postalCode,
      phoneNumber,
      email,
      description,
      gstNumber,
      defaultGstPercentage,
      fssaiLicenseNumber,
      isOpen: false,
      slug:
        restaurantName
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)+/g, "") + `-${nanoid(6)}`,
    });

    // B. CREATE REQUEST
    await db.insert(restaurantRequests).values({
      id: requestId,
      userId: user.id,
      restaurantId,
      requestStatus: "PENDING",
    });

    // 6. SUCCESS RESPONSE
    return res.status(201).json({
      message: "Restaurant application submitted successfully",
    });
  } catch (error) {
    console.error("APPLY RESTAURANT ERROR:", error);
    return res.status(500).json({
      message: "Something went wrong while applying",
    });
  }
});
// GET /api/restaurants/view-request

router.get("/view-request", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    // Get the latest request for this user
    const requests = await db
      .select()
      .from(restaurantRequests)
      .where(eq(restaurantRequests.userId, user.id))
      .orderBy(desc(restaurantRequests.requestedAt)) // Order by newest first
      .limit(1);

    const request = requests[0];

    if (!request) {
      return res.status(404).json({ message: "No restaurant application found for this user" });
    }

    // Fetch the restaurant details
    const restaurantRows = await db
      .select({
        id: restaurants.id,
        slug: restaurants.slug,
        ownerId: restaurants.ownerId,
        restaurantName: restaurants.restaurantName,
        restaurantType: restaurants.restaurantType,
        restaurantAddress: restaurants.restaurantAddress,
        restaurantLogo: restaurants.restaurantLogo,
        restaurantBanner: restaurants.restaurantBanner,
        establishmentYear: restaurants.establishmentYear,
        seatingCapacity: restaurants.seatingCapacity,
        city: restaurants.city,
        state: restaurants.state,
        postalCode: restaurants.postalCode,
        description: restaurants.description,
        phoneNumber: restaurants.phoneNumber,
        email: restaurants.email,
        website: restaurants.website,
        cuisine: restaurants.cuisine,
        rating: restaurants.rating,
        ratingCount: restaurants.ratingCount,
        corporateIdentificationNumber: restaurants.corporateIdentificationNumber,
        gstNumber: restaurants.gstNumber,
        fssaiLicenseNumber: restaurants.fssaiLicenseNumber,
        defaultGstPercentage: restaurants.defaultGstPercentage,
        createdAt: restaurants.createdAt,
        updatedAt: restaurants.updatedAt,
        restaurantStatus: restaurants.restaurantStatus,
        isOpen: restaurants.isOpen,
      })
      .from(restaurants)
      .where(eq(restaurants.id, request.restaurantId))
      .limit(1);

    const restaurant = restaurantRows[0];

    if (!restaurant) {
      return res.status(404).json({ message: "Restaurant data not found" });
    }

    // Return flattened data structure for frontend
    return res.json({
      status: request.requestStatus?.toLowerCase() || 'unknown',
      restaurantName: restaurant.restaurantName || '',
      restaurantType: restaurant.restaurantType || '',
      restaurantAddress: restaurant.restaurantAddress || '',
      city: restaurant.city || '',
      state: restaurant.state || '',
      postalCode: restaurant.postalCode || '',
      phoneNumber: restaurant.phoneNumber || '',
      email: restaurant.email || '',
      adminRemark: request.adminRemark || '',
      createdAt: request.requestedAt || '',
    });
  } catch (error) {
    console.error("VIEW REQUEST ERROR:", error);
    return res.status(500).json({
      message: "Something went wrong while fetching your request",
    });
  }
});

// GET /api/restaurants/has-approved
router.get("/has-approved", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    // Check for latest approved request
    const requests = await db
      .select({
        restaurantId: restaurantRequests.restaurantId,
      })
      .from(restaurantRequests)
      .where(
        and(
          eq(restaurantRequests.userId, user.id),
          eq(restaurantRequests.requestStatus, "APPROVED")
        )
      )
      .orderBy(desc(restaurantRequests.requestedAt))
      .limit(1);

    if (!requests.length) {
      return res.status(200).json({ ok: false });
    }

    // Optional: ensure restaurant actually exists
    const restaurantExists = await db
      .select({ id: restaurants.id })
      .from(restaurants)
      .where(eq(restaurants.id, requests[0].restaurantId))
      .limit(1);

    if (!restaurantExists.length) {
      return res.status(200).json({ ok: false });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error("HAS APPROVED ERROR:", error);
    return res.status(404).json({ ok: false });
  }
});

export default router;