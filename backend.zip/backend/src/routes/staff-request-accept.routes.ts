import { Router } from "express";
import { db } from "../db/db";
import { staffInvites } from "../db/schema/staff-invites";
import { eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { restaurantManagers } from "../db/schema/restaurant-managers";
import { nanoid } from "nanoid";
import { authUsers } from "../db/schema/auth-users";
import { isRestaurantOwner } from "../lib/checkRoles";

const router = Router();

router.get("/view-invite/:inviteToken", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { inviteToken } = req.params;

    // ✅ 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. FETCH INVITE BY TOKEN
    const invite = (
      await db
        .select()
        .from(staffInvites)
        .where(eq(staffInvites.inviteToken, inviteToken))
    )[0];

    if (!invite) {
      return res.status(404).json({ message: "Invite not found" });
    }

    // ✅ 3. OWNERSHIP CHECK (EMAIL FIRST, THEN USER_ID)
    const isEmailOwner = invite.invitedEmail === user.email;
    const isLinkedUser = invite.user_id && invite.user_id === user.id;

    // 4. INVALID ACCESS
    if (!isEmailOwner && !isLinkedUser) {
      return res.status(403).json({
        status: "invalid",
        message: "Invalid invite access",
      });
    }

    // 5. ALREADY USED
    if (invite.respondedAt) {
      return res.status(400).json({
        status: "used",
        message: "Invite already used",
      });
    }

    // 6. EXPIRED
    if (new Date() > invite.expiresAt) {
      return res.status(400).json({
        status: "expired",
        message: "Invite has expired",
      });
    }

    // 7. SUCCESS RESPONSE
    return res.status(200).json({ invite });
    } catch (error) {
        console.error("VIEW INVITE ERROR:", error);
        return res.status(500).json({ message: "Internal server error" });
      }
    });

router.post(
  "/:inviteToken/accept-invite",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { inviteToken } = req.params;

      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const invite = (
        await db
          .select()
          .from(staffInvites)
          .where(eq(staffInvites.inviteToken, inviteToken))
      )[0];

      if (!invite) {
        return res.status(404).json({ status: "not_found", message: "Invite not found" });
      }

      if (invite.inviteStatus !== "PENDING") {
        return res.status(400).json({ status: "used", message: "Invite already responded to" });
      }

      if (new Date() > invite.expiresAt) {
        return res.status(400).json({ status: "expired", message: "Invite has expired" });
      }

      // Ownership check
      if (invite.invitedEmail !== user.email && invite.user_id !== user.id) {
        return res
          .status(403)
          .json({ status: "invalid", message: "You are not allowed to accept this invite" });
      }

      // 1. Create staff access
      await db.insert(restaurantManagers).values({
        id: nanoid(),
        userId: user.id,
        restaurantId: invite.restaurantId,
        role: invite.role as any,
        status: "active",
        createdAt: new Date(),
        updatedAt: new Date(),
      } as any);

      // 2. Mark invite as accepted
      await db
        .update(staffInvites)
        .set({
          inviteStatus: "ACCEPTED",
          respondedAt: new Date(),
          user_id: user.id,
        })
        .where(eq(staffInvites.inviteToken, inviteToken));

      await db
        .update(authUsers)
        .set({
          role: "restaurant",
        })
        .where(eq(authUsers.id, user.id));

      return res.status(200).json({ message: "Invite accepted successfully" });
    } catch (error) {
      console.error("Error accepting invite:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get("/my-invites", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    if (!user || !user.email) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const invites = await db
      .select()
      .from(staffInvites)
      .where(eq(staffInvites.invitedEmail, user.email));

    return res.status(200).json({ invites });
  } catch (error) {
    console.error("Error fetching invites:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.post(
  "/:inviteToken/reject-invite",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { inviteToken } = req.params;

      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const invite = (
        await db
          .select()
          .from(staffInvites)
          .where(eq(staffInvites.inviteToken, inviteToken))
      )[0];

      if (!invite) {
        return res.status(404).json({ status: "not_found", message: "Invite not found" });
      }

      if (invite.inviteStatus !== "PENDING") {
        return res.status(400).json({ status: "used", message: "Invite already responded to" });
      }

      if (new Date() > invite.expiresAt) {
        return res.status(400).json({ status: "expired", message: "Invite has expired" });
      }

      // Ownership check
      if (invite.invitedEmail !== user.email && invite.user_id !== user.id) {
        return res
          .status(403)
          .json({ status: "invalid", message: "You are not allowed to accept this invite" });
      }

      // 1. Mark invite as rejected
      await db
        .update(staffInvites)
        .set({
          inviteStatus: "REJECTED",
          respondedAt: new Date(),
          user_id: user.id,
        })
        .where(eq(staffInvites.inviteToken, inviteToken));

      return res.status(200).json({ message: "Invite rejected successfully" });
    } catch (error) {
      console.error("Error rejecting invite:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;
