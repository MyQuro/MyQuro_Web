import { Router } from "express";
import { requireAuth } from "../auth/requireAuth";
import { db } from "../db/db";
import { and, eq } from "drizzle-orm";
import {
  totalBillingAmount,
  finalAmount,
  calculateSubtotal,
  calculateDiscount,
  calculateTaxableBase,
  calculateGST,
  calculateGrandTotal,
} from "../lib/billing";
import { tableSession } from "../db/schema/table-session";
import { orderItems } from "../db/schema/order-items";

const router = Router();

// Define your billing routes here
router.get("/:tableSessionId/total", requireAuth, async (req, res) => {
  const { tableSessionId } = req.params;

  try {
    const totalAmount = await totalBillingAmount(tableSessionId);
    res.json({ totalAmount });
  } catch (error) {
    res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

router.get("/:tableSessionId/final-amount", requireAuth, async (req, res) => {
  const { tableSessionId } = req.params;
  const { discountPercentage, taxRate } = req.query;

  try {
    const totalAmount = await totalBillingAmount(tableSessionId);
    const finalAmt = await finalAmount(
      tableSessionId,
      totalAmount,
      Number(discountPercentage) || 0,
      Number(taxRate) || 0
    );
    res.json({ finalAmount: finalAmt });
  } catch (error) {
    res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

router.post("/:tableSessionId/generate-bill", requireAuth, async (req, res) => {
  const { tableSessionId } = req.params;
  const { discountPercentage, taxRate } = req.body;

  try {
    // 1️⃣ Fetch session
    const session = await db
      .select()
      .from(tableSession)
      .where(eq(tableSession.id, tableSessionId))
      .limit(1);

    if (session.length === 0) {
      return res.status(404).json({ error: "Table session not found" });
    }

    if (session[0].status === "cancelled") {
      return res.status(400).json({ error: "Cannot bill a cancelled session" });
    }

    if (session[0].paymentStatus === "paid") {
      return res.status(400).json({ error: "Session already paid" });
    }

    // 2️⃣ Fetch served items
    const sessionOrders = await db
      .select({
        quantity: orderItems.quantity,
        unitPrice: orderItems.unitPrice,
      })
      .from(orderItems)
      .where(
        and(
          eq(orderItems.tableSessionId, tableSessionId),
          eq(orderItems.status, "served")
        )
      );

    // 3️⃣ Recalculate everything fresh
    const subtotal = calculateSubtotal(sessionOrders);

    const discountAmount = calculateDiscount(
      subtotal,
      Number(discountPercentage)
    );

    const taxableAmount = calculateTaxableBase(subtotal, discountAmount);

    const gstAmount = calculateGST(taxableAmount, Number(taxRate));

    const grandTotal = calculateGrandTotal(taxableAmount, gstAmount);

    // 4️⃣ Freeze values & mark as paid
    await db
      .update(tableSession)
      .set({
        frozenSubtotal: subtotal,
        frozenDiscountAmount: discountAmount,
        frozenTaxableAmount: taxableAmount,
        frozenGstAmount: gstAmount,
        grandTotal,
        paymentStatus: "payment_pending",
        status: "payment_pending",
        finalBillAmount: grandTotal,
      })
      .where(eq(tableSession.id, tableSessionId));

    // 5️⃣ Response
    return res.status(200).json({
      message: "Bill generated successfully",
      tableSessionId,
      subtotal,
      discountAmount,
      taxableAmount,
      gstAmount,
      grandTotal,
    });
  } catch (error) {
    return res.status(500).json({
      error:
        error instanceof Error ? error.message : "An unknown error occurred",
    });
  }
});

export default router;
