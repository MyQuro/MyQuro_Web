import { Router } from "express";
import { db } from "../db/db";
import { staffInvites } from "../db/schema/staff-invites";
import { restaurantManagers } from "../db/schema/restaurant-managers"; // Import restaurantManagers
import { and, eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { nanoid } from "nanoid";
import { isRestaurantOwner } from "../lib/checkRoles";

const router = Router();

// POST /api/restaurants/:restaurantId/invite-staff
router.post(
  "/:restaurantId/invite-staff",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { invitedEmail } = req.body;

      // 1. AUTH CHECK
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // 2. ROLE CHECK (Fix: await the async function)
      const isOwner = await isRestaurantOwner(user.id, restaurantId);
      if (!isOwner) {
        return res
          .status(403)
          .json({ message: "You do not own this restaurant" });
      }

      // 3. FETCH MANAGER RECORD (Fix for FK violation)
      // We need the ID from the 'restaurant_managers' table, not 'auth_users'
      const managerRecord = (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.userId, user.id),
              eq(restaurantManagers.restaurantId, restaurantId)
            )
          )
          .limit(1)
      )[0];

      if (!managerRecord) {
        return res
          .status(403)
          .json({ message: "Manager record not found for this user" });
      }

      // 4. CREATE INVITE
      const inviteToken = nanoid(32);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 1); // Expires in 1 day
      const role = req.body.role;

      await db.insert(staffInvites).values({
        id: nanoid(),
        restaurantId,
        invitedByManagerId: managerRecord.id, // Use the manager ID here
        invitedEmail,
        role,
        inviteToken,
        expiresAt,
      });

      // 5. SUCCESS RESPONSE
      return res
        .status(201)
        .json({ message: "Staff invite created", inviteToken });
    } catch (error) {
      console.error("INVITE STAFF ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

// GET /api/restaurants/:restaurantId/staff-invites
router.get(
  "/:restaurantId/staff-invites",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;

      // 1. AUTH CHECK
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // 2. ROLE CHECK (Fix: await the async function)
      const isOwner = await isRestaurantOwner(user.id, restaurantId);
      if (!isOwner) {
        return res
          .status(403)
          .json({ message: "You do not own this restaurant" });
      }

      // 3. FETCH INVITES
      const invites = await db
        .select()
        .from(staffInvites)
        .where(eq(staffInvites.restaurantId, restaurantId));

      // 4. SUCCESS RESPONSE
      return res.status(200).json({ invites });
    } catch (error) {
      console.error("FETCH STAFF INVITES ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get(
  "/restaurant-role/:userId",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { userId } = req.params;

      // 1. AUTH CHECK
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // 2. FETCH ROLE
      const managerRecord = await db
        .select({ role: restaurantManagers.role })
        .from(restaurantManagers)
        .where(
          and(
            eq(restaurantManagers.userId, userId),
            eq(restaurantManagers.status, "active")
          )
        )
        .limit(1);

      if (managerRecord.length === 0) {
        return res
          .status(404)
          .json({ message: "No role found for this user in the restaurant" });
      }

      // 3. SUCCESS RESPONSE
      return res.status(200).json({ role: managerRecord[0].role });
    } catch (error) {
      console.error("FETCH STAFF ROLE ERROR:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;
