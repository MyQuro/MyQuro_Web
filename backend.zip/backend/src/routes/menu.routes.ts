import { Router } from "express";
import { db } from "../db/db";
import { restaurants } from "../db/schema/restaurants";
import { menuCategories } from "../db/schema/menu-categories";
import { menuItems } from "../db/schema/menu-items";
import { menuItemVariants } from "../db/schema/menu-item-variants";
import { and, eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";
import { nanoid } from "nanoid";

const router = Router();

router.post(
  "/:restaurantId/menu/categories",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      const { name, description, display_order } = req.body;
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to add menu categories",
        });
      }
      const newCategory = {
        id: nanoid(),
        restaurantId,
        category: name,
        description,
        displayOrder: display_order,
      };
      await db.insert(menuCategories).values(newCategory);
      return res
        .status(201)
        .json({ message: "Menu category created", category: newCategory });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.post("/:restaurantId/menu/items", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { restaurantId } = req.params;
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
    const { name, description, categoryId } = req.body;

    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!hasAccess) {
      return res.status(403).json({
        message: "You do not have permission to add menu items",
      });
    }

    const newItem = {
      id: nanoid(),
      restaurantId,
      categoryId,
      name,
      description,
    };

    await db.insert(menuItems).values(newItem);
    return res
      .status(201)
      .json({ message: "Menu item created", item: newItem });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.post(
  "/:restaurantId/menu/items/:itemId/variants",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;
      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      const { name, price, additionalInfo } = req.body;

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to add menu item variants",
        });
      }

      // Validate price - should be in paise (integer)
      if (
        price === undefined ||
        typeof price !== "number" ||
        price <= 0 ||
        !Number.isInteger(price)
      ) {
        return res
          .status(400)
          .json({
            message: "Invalid price - must be a positive integer in paise",
          });
      }

      if (
        !additionalInfo ||
        typeof additionalInfo !== "object" ||
        Array.isArray(additionalInfo)
      ) {
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const item = await db
        .select()
        .from(menuItems)
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        )
        .limit(1);

      if (!item.length) {
        return res
          .status(404)
          .json({ message: "Menu item not found for this restaurant" });
      }

      const newVariant = {
        id: nanoid(),
        menuItemId: itemId,
        variantName: name,
        foodType: additionalInfo.foodType,
        portionSize: additionalInfo.portionSize,
        price, // price is already in paise (integer)
      };

      await db.insert(menuItemVariants).values(newVariant);
      return res
        .status(201)
        .json({ message: "Menu item variant created", variant: newVariant });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get("/:restaurantId/menu", async (req, res) => {
  try {
    const { restaurantId } = req.params;

    const categories = await db
      .select()
      .from(menuCategories)
      .where(
        and(
          eq(menuCategories.restaurantId, restaurantId),
          eq(menuCategories.isActive, true)
        )
      );

    const menu = [];

    for (const category of categories) {
      const items = await db
        .select()
        .from(menuItems)
        .where(
          and(
            eq(menuItems.categoryId, category.id),
            eq(menuItems.isActive, true)
          )
        );

      const itemsWithVariants = [];

      for (const item of items) {
        const variants = await db
          .select()
          .from(menuItemVariants)
          .where(
            and(
              eq(menuItemVariants.menuItemId, item.id),
              eq(menuItemVariants.isActive, true)
            )
          );

        // Variants already have price in paise (integer)
        itemsWithVariants.push({ ...item, variants });
      }

      menu.push({ ...category, items: itemsWithVariants });
    }

    return res.status(200).json({ menu });
  } catch (error) {
    console.error("Error fetching menu:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.patch(
  "/:restaurantId/menu/categories/:categoryId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, categoryId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to deactivate menu categories",
        });
      }

      await db
        .update(menuCategories)
        .set({ isActive: false })
        .where(eq(menuCategories.id, categoryId));

      return res
        .status(200)
        .json({ message: "Menu category updated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/update",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;
      const { name, description, additionalInfo } = req.body;

      if (
        additionalInfo &&
        (typeof additionalInfo !== "object" || Array.isArray(additionalInfo))
      ) {
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to update menu items",
        });
      }

      const updateData: any = {};
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (additionalInfo !== undefined)
        updateData.additionalInfo = additionalInfo;

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No valid fields to update" });
      }

      await db
        .update(menuItems)
        .set(updateData)
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item updated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/variants/:variantId/update",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId, variantId } = req.params;
      const { variantName, price, additionalInfo } = req.body;

      // Validate price - should be in paise (integer)
      if (
        price !== undefined &&
        (typeof price !== "number" || price <= 0 || !Number.isInteger(price))
      ) {
        return res
          .status(400)
          .json({
            message: "Invalid price - must be a positive integer in paise",
          });
      }

      if (
        additionalInfo &&
        (typeof additionalInfo !== "object" || Array.isArray(additionalInfo))
      ) {
        return res.status(400).json({ message: "Invalid additionalInfo" });
      }

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to update menu item variants",
        });
      }

      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, itemId));

      if (!items || items.length === 0) {
        return res.status(404).json({ message: "Menu item not found" });
      }

      if (items[0].restaurantId !== restaurantId) {
        return res.status(403).json({
          message: "You do not have permission to update this variant",
        });
      }

      const updateData: any = {};
      if (variantName !== undefined) updateData.variantName = variantName;
      if (price !== undefined) updateData.price = price; // price is in paise (integer)

      if (additionalInfo) {
        if (additionalInfo.foodType !== undefined) {
          updateData.foodType = additionalInfo.foodType;
        }
        if (additionalInfo.portionSize !== undefined) {
          updateData.portionSize = additionalInfo.portionSize;
        }
      }

      await db
        .update(menuItemVariants)
        .set(updateData)
        .where(
          and(
            eq(menuItemVariants.id, variantId),
            eq(menuItemVariants.menuItemId, itemId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item variant updated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to deactivate menu items",
        });
      }

      await db
        .update(menuItems)
        .set({ isActive: false })
        .where(
          and(
            eq(menuItems.id, itemId),
            eq(menuItems.restaurantId, restaurantId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item deactivated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/items/:itemId/variants/:variantId/deactivate",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId, itemId, variantId } = req.params;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }

      if (!hasAccess) {
        return res.status(403).json({
          message:
            "You do not have permission to deactivate menu item variants",
        });
      }

      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, itemId));

      if (!items || items.length === 0) {
        return res.status(404).json({ message: "Menu item not found" });
      }

      if (items[0].restaurantId !== restaurantId) {
        return res.status(403).json({
          message: "You do not have permission to deactivate this variant",
        });
      }

      await db
        .update(menuItemVariants)
        .set({ isActive: false })
        .where(
          and(
            eq(menuItemVariants.id, variantId),
            eq(menuItemVariants.menuItemId, itemId)
          )
        );

      return res
        .status(200)
        .json({ message: "Menu item variant deactivated successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.patch(
  "/:restaurantId/menu/categories/reorder",
  requireAuth,
  async (req: any, res) => {
    try {
      const user = req.user;
      const { restaurantId } = req.params;
      const { orderedCategoryIds } = req.body;

      const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);
      if (!user || user.role !== "restaurant") {
        return res.status(401).json({ message: "Authentication required" });
      }
      if (!hasAccess) {
        return res.status(403).json({
          message: "You do not have permission to reorder menu categories",
        });
      }

      for (let index = 0; index < orderedCategoryIds.length; index++) {
        const categoryId = orderedCategoryIds[index];
        await db
          .update(menuCategories)
          .set({ displayOrder: index })
          .where(
            and(
              eq(menuCategories.id, categoryId),
              eq(menuCategories.restaurantId, restaurantId)
            )
          );
      }

      return res
        .status(200)
        .json({ message: "Menu categories reordered successfully" });
    } catch (error) {
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.get("/:restaurantId/menu/manage", requireAuth, async (req: any, res) => {
  try {
    const { restaurantId } = req.params;
    const user = req.user;
    const hasAccess = await isRestaurantOwnerOrManager(user.id, restaurantId);

    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (!hasAccess) {
      return res.status(403).json({
        message: "You do not have permission to view this menu",
      });
    }

    const categories = await db
      .select()
      .from(menuCategories)
      .where(eq(menuCategories.restaurantId, restaurantId));

    const menu = [];

    for (const category of categories) {
      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.categoryId, category.id));

      const itemsWithVariants = [];

      for (const item of items) {
        const variants = await db
          .select()
          .from(menuItemVariants)
          .where(eq(menuItemVariants.menuItemId, item.id));

        // Variants already have price in paise (integer)
        itemsWithVariants.push({ ...item, variants });
      }

      menu.push({ ...category, items: itemsWithVariants });
    }

    return res.status(200).json({ menu });
  } catch (error) {
    return res.status(500).json({ message: "Internal server error" });
  }
});

export default router;
