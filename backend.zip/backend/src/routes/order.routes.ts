import { Router } from "express";
import { db } from "../db/db";
import { orders } from "../db/schema/orders";
import { orderItems } from "../db/schema/order-items";
import { tableSession } from "../db/schema/table-session";
import { menuItems } from "../db/schema/menu-items"; // ✅ Added import
import { and, eq } from "drizzle-orm";
import { requireAuth } from "../auth/requireAuth";
import { verifyTableSession } from "../lib/verifyTableSession";
import { nanoid } from "nanoid";
import { restaurantManagers } from "../db/schema/restaurant-managers";
import { menuItemVariants } from "../db/schema/menu-item-variants";
import {
  calculateSubtotal,
  calculateDiscount,
  calculateTaxableBase,
  calculateGST,
  calculateGrandTotal,
} from "../lib/billing";
import { isRestaurantOwnerOrManager } from "../lib/checkRoles";

const router = Router();

// POST /make-order
router.post("/make-order", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { tableSessionId, notes, items } = req.body;

    if (!tableSessionId || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Invalid order payload" });
    }

    // ✅ 1. Fetch table session ONCE
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    // ✅ 2. Enforce HARD LOCKS
    if (session.status !== "active") {
      return res.status(400).json({ message: "Session is not active" });
    }

    if (session.paymentStatus === "paid") {
      return res.status(403).json({
        message: "Payment already completed. Cannot place new order.",
      });
    }

    const { restaurantId, tableId } = session;

    // ✅ 3. Compute backend price snapshot (in paise)
    let computedTotal = 0;
    const computedItems: any[] = [];

    for (const item of items) {
      const { menuItemId, menuItemVariantId, quantity, itemNotes } = item;

      if (!menuItemId || !menuItemVariantId || !quantity || quantity <= 0) {
        return res.status(400).json({ message: "Invalid item data" });
      }

      // ✅ Fetch variant price from DB (already in paise)
      const variant = (
        await db
          .select()
          .from(menuItemVariants)
          .where(eq(menuItemVariants.id, menuItemVariantId))
          .limit(1)
      )[0];

      if (!variant || !variant.isActive || !variant.isAvailable) {
        return res
          .status(400)
          .json({ message: "Invalid or unavailable variant" });
      }

      const unitPriceSnapshot = variant.price; // already in paise
      const totalPrice = unitPriceSnapshot * quantity; // paise

      computedTotal += totalPrice;

      computedItems.push({
        id: nanoid(),
        menuItemId,
        menuItemVariantId,
        variantNameSnapshot: variant.variantName,
        quantity,
        unitPriceSnapshot,
        totalPrice,
        itemNotes,
      });
    }

    // ✅ 4. Create order
    const orderId = nanoid();
    const userId = user.id;
    await db.update(tableSession).set({
      id: tableSessionId,
      tableId,
      restaurantId,
      status: "active",
      paymentStatus: "unpaid",
      createdByUserId: userId,
    });
    await db.insert(orders).values({
      id: orderId,
      tableSessionId,
      restaurantId,
      tableId,
      placedByUserId: user.id,
      notes,
      status: "placed",
    });

    // ✅ 5. Insert order items
    for (const item of computedItems) {
      const variant = (
        await db
          .select()
          .from(menuItemVariants)
          .where(eq(menuItemVariants.id, item.menuItemVariantId))
          .limit(1)
      )[0];
      if (variant.menuItemId !== item.menuItemId) {
        return res.status(400).json({
          message: "Variant does not belong to the specified menu item",
        });
      }
      await db.insert(orderItems).values({
        id: item.id,
        orderId,
        tableSessionId,
        restaurantId,

        menuItemId: item.menuItemId,
        menuItemVariantId: item.menuItemVariantId,

        quantity: item.quantity,
        unitPrice: item.unitPriceSnapshot, // paise
        totalPrice: item.totalPrice, // paise

        notes: item.itemNotes,
        status: "placed",
      });
    }

    // ✅ 6. Success response
    return res.status(201).json({
      message: "Order created successfully",
      orderId,
      totalAmount: computedTotal, // return in paise
    });
  } catch (error) {
    console.error("Error creating order:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// GET /orders/:tableSessionId
router.get("/:tableSessionId", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const tableSessionId = req.params.tableSessionId;

    const isValidSession = await verifyTableSession(tableSessionId);
    if (!isValidSession) {
      return res
        .status(400)
        .json({ message: "Invalid or inactive table session" });
    }

    // Fetch the session once
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    const isCustomer = session.createdByUserId === user.id;

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, session.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = isCustomer || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to view these orders" });
    }

    const ordersList = await db
      .select()
      .from(orders)
      .where(eq(orders.tableSessionId, tableSessionId));

    // ✅ Updated query to join with menuItems and menuItemVariants
    const orderItemsRaw = await db
      .select()
      .from(orderItems)
      .leftJoin(menuItems, eq(orderItems.menuItemId, menuItems.id))
      .leftJoin(
        menuItemVariants,
        eq(orderItems.menuItemVariantId, menuItemVariants.id)
      )
      .where(eq(orderItems.tableSessionId, tableSessionId));

    // ✅ Flatten the result to include names
    const orderItemsList = orderItemsRaw.map((row) => ({
      ...row.order_items,
      itemName: row.menu_items?.name,
      variantName: row.menu_item_variants?.variantName,
    }));

    // Attach items to their respective orders
    const ordersWithItems = ordersList.map((order) => {
      return {
        ...order,
        items: orderItemsList.filter(
          (item) => item.orderId === order.id && item.status !== "cancelled"
        ),
      };
    });

    return res.status(200).json({ orders: ordersWithItems });
  } catch (error) {
    console.error("Error fetching orders:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/cancel
router.patch("/:orderId/cancel", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;

    const orderRow = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    if (!orderRow) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (
      orderRow.status === "served" ||
      orderRow.status === "preparing" ||
      orderRow.status === "cancelled"
    ) {
      return res.status(400).json({ message: "Order cannot be cancelled" });
    }

    // Fetch session to enforce payment locks
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(eq(tableSession.id, orderRow.tableSessionId))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    if (session.paymentStatus === "paid") {
      return res
        .status(403)
        .json({ message: "Payment already completed. Cannot cancel order." });
    }

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, orderRow.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = orderRow.placedByUserId === user.id || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to cancel this order" });
    }

    await db
      .update(orders)
      .set({ status: "cancelled" })
      .where(eq(orders.id, orderId));

    return res.status(200).json({ message: "Order cancelled successfully" });
  } catch (error) {
    console.error("Error cancelling order:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/items/update
router.patch("/:orderId/items/update", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;
    const { items } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Invalid items payload" });
    }

    if (!orderId) {
      return res.status(400).json({ message: "Order ID is required" });
    }

    // ✅ Fetch order
    const order = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    // ✅ Fetch session
    const session = (
      await db
        .select()
        .from(tableSession)
        .where(and(eq(tableSession.id, order.tableSessionId)))
        .limit(1)
    )[0];

    if (!session) {
      return res.status(404).json({ message: "Table session not found" });
    }

    // ✅ HARD LOCKS
    if (session.paymentStatus === "paid") {
      return res
        .status(403)
        .json({ message: "Payment already completed. Cannot modify order." });
    }

    if (order.status !== "placed") {
      return res
        .status(403)
        .json({ message: "Order can no longer be modified" });
    }

    // ✅ Authorization: customer OR restaurant staff
    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, order.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    const isAllowedUser = order.placedByUserId === user.id || isManager;

    if (!isAllowedUser) {
      return res
        .status(403)
        .json({ message: "You are not authorized to update this order" });
    }

    // ✅ Process each item
    for (const item of items) {
      const {
        action,
        orderItemId,
        menuItemId,
        menuItemVariantId,
        quantity,
        itemNotes,
      } = item;

      // ---------- ADD ITEM ----------
      if (action === "add") {
        if (!menuItemVariantId || !quantity || quantity <= 0) {
          return res.status(400).json({ message: "Invalid add item payload" });
        }

        const variant = (
          await db
            .select()
            .from(menuItemVariants)
            .where(eq(menuItemVariants.id, menuItemVariantId))
            .limit(1)
        )[0];
        if (variant.menuItemId !== menuItemId) {
          return res
            .status(400)
            .json({ message: "Variant does not belong to this menu item" });
        }

        if (!variant || !variant.isActive || !variant.isAvailable) {
          return res
            .status(400)
            .json({ message: "Invalid or unavailable variant" });
        }

        const unitPriceSnapshot = variant.price; // already in paise
        const totalPrice = unitPriceSnapshot * quantity; // paise

        await db.insert(orderItems).values({
          id: nanoid(),
          orderId,
          tableSessionId: order.tableSessionId,
          restaurantId: order.restaurantId,

          menuItemId,
          menuItemVariantId,

          quantity,
          unitPrice: unitPriceSnapshot, // paise
          totalPrice, // paise

          notes: itemNotes,
          status: "placed",
        });
      }

      // ---------- UPDATE ITEM ----------
      if (action === "update") {
        if (!orderItemId || !quantity || quantity <= 0) {
          return res.status(400).json({ message: "Invalid update payload" });
        }

        const existingItem = (
          await db
            .select()
            .from(orderItems)
            .where(
              and(
                eq(orderItems.id, orderItemId),
                eq(orderItems.orderId, orderId)
              )
            )
            .limit(1)
        )[0];

        if (!existingItem) {
          return res.status(404).json({ message: "Order item not found" });
        }

        const newTotal = existingItem.unitPrice * quantity; // paise

        await db
          .update(orderItems)
          .set({
            quantity,
            totalPrice: newTotal,
            notes: itemNotes ?? existingItem.notes,
          })
          .where(eq(orderItems.id, orderItemId));
      }

      // ---------- REMOVE ITEM ----------
      if (action === "remove") {
        if (!orderItemId) {
          return res.status(400).json({ message: "Invalid remove payload" });
        }

        await db
          .update(orderItems)
          .set({
            status: "cancelled",
            quantity: 0,
            totalPrice: 0,
          })
          .where(eq(orderItems.id, orderItemId));
      }
    }

    // ✅ Recalculate order total (in paise)
    const updatedItems = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));

    const newTotalAmountInPaise = updatedItems.reduce(
      (sum: number, item: any) => sum + (item.totalPrice || 0),
      0
    );

    return res.status(200).json({
      message: "Order items updated successfully",
      orderId,
      updatedTotal: newTotalAmountInPaise, // return in paise
    });
  } catch (error) {
    console.error("Error updating order items:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// PATCH /orders/:orderId/status
router.patch("/:orderId/status", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const orderId = req.params.orderId;
    const { status } = req.body;

    if (
      !status ||
      !["placed", "preparing", "served", "cancelled"].includes(status)
    ) {
      return res.status(400).json({ message: "Invalid status value" });
    }

    const orderRow = (
      await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    )[0];

    const validTransitions: Record<string, string[]> = {
      placed: ["preparing", "cancelled"],
      preparing: ["served"],
      served: [],
      cancelled: [],
    };

    if (!orderRow) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (!validTransitions[orderRow.status].includes(status)) {
      return res.status(400).json({
        message: `Invalid status transition from ${orderRow.status} to ${status}`,
      });
    }

    const isManager =
      (
        await db
          .select()
          .from(restaurantManagers)
          .where(
            and(
              eq(restaurantManagers.restaurantId, orderRow.restaurantId),
              eq(restaurantManagers.userId, user.id)
            )
          )
          .limit(1)
      ).length > 0;

    if (!isManager) {
      return res
        .status(403)
        .json({ message: "You are not authorized to update order status" });
    }

    // Update the order status
    await db.update(orders).set({ status }).where(eq(orders.id, orderId));

    // If the status is changed to "served", calculate billing details
    if (status === "served") {
      // 1. Update all items in this order to 'served' so they are included in calculation
      await db
        .update(orderItems)
        .set({ status: "served" })
        .where(eq(orderItems.orderId, orderId));

      const session = (
        await db
          .select()
          .from(tableSession)
          .where(eq(tableSession.id, orderRow.tableSessionId))
          .limit(1)
      )[0];

      if (!session) {
        return res.status(404).json({ message: "Table session not found" });
      }

      // 2. Fetch ALL served items for this SESSION (not just this order)
      const sessionItems = await db
        .select({
          unitPrice: orderItems.unitPrice,
          quantity: orderItems.quantity,
        })
        .from(orderItems)
        .where(
          and(
            eq(orderItems.tableSessionId, session.id),
            eq(orderItems.status, "served")
          )
        );

      // 3. Calculate billing details
      const subtotal = calculateSubtotal(sessionItems);
      const discountAmount = calculateDiscount(
        subtotal,
        session.discountPercentage || 0
      );
      const taxableBase = calculateTaxableBase(subtotal, discountAmount);

      // Use active gstRate, fallback to 0
      const currentGstRate = session.gstRate || 0;
      const gstAmount = calculateGST(taxableBase, currentGstRate);

      const grandTotal = calculateGrandTotal(taxableBase, gstAmount);

      // 4. Update the table session with billing details
      await db
        .update(tableSession)
        .set({
          subtotal,
          discountAmount,
          taxableBase,
          gstAmount,
          grandTotal,
        })
        .where(eq(tableSession.id, session.id));
    }

    return res
      .status(200)
      .json({ message: "Order status updated successfully" });
  } catch (error) {
    console.error("Error updating order status:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// GET /:userId/user-orders
router.get("/:userId/user-orders", requireAuth, async (req: any, res) => {
  try {
    const userId = req.params.userId;

    if (req.user.id !== userId) {
      return res
        .status(403)
        .json({ message: "You are not authorized to view these orders" });
    }

    const userOrders = await db
      .select()
      .from(orders)
      .where(eq(orders.placedByUserId, userId));

    return res.status(200).json({ orders: userOrders });
  } catch (error) {
    console.error("Error fetching user orders:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

// GET restaurant orders for managers
router.get(
  "/restaurant/:restaurantId/manager-orders",
  requireAuth,
  async (req: any, res) => {
    try {
      const restaurantId = req.params.restaurantId;
      const user = req.user;

      const isAllowedUser = await isRestaurantOwnerOrManager(
        user.id,
        restaurantId
      );
      if (!isAllowedUser) {
        return res
          .status(403)
          .json({ message: "You are not authorized to view these orders" });
      }

      const restaurantOrders = await db
        .select()
        .from(orders)
        .where(eq(orders.restaurantId, restaurantId));

      return res.status(200).json({ orders: restaurantOrders });
    } catch (error) {
      console.error("Error fetching restaurant orders:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  }
);

export default router;
