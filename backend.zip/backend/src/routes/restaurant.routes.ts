import { Router } from "express";
import { db } from "../db/db";
import { restaurants } from "../db/schema/restaurants";
import { restaurantManagers } from "../db/schema/restaurant-managers";
import { restaurantRequests } from "../db/schema/restaurant-requests";
import { requireAuth } from "../auth/requireAuth";
import {
  isRestaurantOwnerOrManager,
  isRestaurantStaff,
} from "../lib/checkRoles";
import { eq, and, isNull } from "drizzle-orm";

const router = Router();

// Get all restaurants
router.get("/", async (req: any, res) => {
  try {
    const allRestaurants = await db
      .selectDistinct({
        id: restaurants.id,
        slug: restaurants.slug,
        ownerId: restaurants.ownerId,
        restaurantName: restaurants.restaurantName,
        restaurantType: restaurants.restaurantType,
        restaurantAddress: restaurants.restaurantAddress,
        restaurantLogo: restaurants.restaurantLogo,
        restaurantBanner: restaurants.restaurantBanner,
        establishmentYear: restaurants.establishmentYear,
        seatingCapacity: restaurants.seatingCapacity,
        city: restaurants.city,
        state: restaurants.state,
        postalCode: restaurants.postalCode,
        description: restaurants.description,
        phoneNumber: restaurants.phoneNumber,
        email: restaurants.email,
        website: restaurants.website,
        cuisine: restaurants.cuisine,
        rating: restaurants.rating,
        ratingCount: restaurants.ratingCount,
        corporateIdentificationNumber: restaurants.corporateIdentificationNumber,
        gstNumber: restaurants.gstNumber,
        fssaiLicenseNumber: restaurants.fssaiLicenseNumber,
        defaultGstPercentage: restaurants.defaultGstPercentage,
        createdAt: restaurants.createdAt,
        updatedAt: restaurants.updatedAt,
        restaurantStatus: restaurants.restaurantStatus,
        isOpen: restaurants.isOpen,
      })
      .from(restaurants)
      .innerJoin(
        restaurantRequests,
        and(
          eq(restaurantRequests.restaurantId, restaurants.id),
          eq(restaurantRequests.requestStatus, "APPROVED")
        )
      );

    res.status(200).json({ restaurants: allRestaurants });
  } catch (error) {
    console.error("FETCH RESTAURANTS ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get restaurant details by ID for everyone
router.get("/:id", async (req: any, res) => {
  try {
    const restaurantId = req.params.id;
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(eq(restaurants.id, restaurantId))
      .limit(1);

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    res.status(200).json({ restaurant: restaurant[0] });
  } catch (error) {
    console.error("FETCH RESTAURANT BY ID ERROR:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

// Get my restaurant with role-based access control
router.get("/my-restaurant", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;

    // ✅ 1. AUTH CHECK
    if (!user || user.role !== "restaurant") {
      return res.status(401).json({ message: "Authentication required" });
    }

    // ✅ 2. VERIFY OWNER OR MANAGER ACCESS
    const restaurant = await db
      .select()
      .from(restaurants)
      .where(eq(restaurants.ownerId, user.id))
      .limit(1);

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "Restaurant not found" });
    }

    const hasAccess = await isRestaurantOwnerOrManager(
      user.id,
      restaurant[0].id
    );
    if (!hasAccess) {
      return res.status(403).json({ message: "Access denied" });
    }

    // ✅ 3. SUCCESS RESPONSE
    return res.status(200).json({ restaurant: restaurant[0] });
  } catch (error) {
    console.error("FETCH MY RESTAURANT ERROR:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/:userId/id", requireAuth, async (req: any, res) => {
  try {
    const user = req.user;
    const { usersId } = req.params;

    // 1. AUTH CHECK
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // 2. FETCH RESTAURANT BY OWNER ID
    const restaurant = await db
      .select({ id: restaurantManagers.restaurantId })
      .from(restaurantManagers)
      .where(eq(restaurantManagers.userId, usersId))
      .limit(1);

    if (restaurant.length === 0) {
      return res.status(404).json({ message: "No restaurant found for this user" });
    }

    // 3. SUCCESS RESPONSE
    return res.status(200).json({ restaurantId: restaurant[0].id });
  } catch (error) {
    console.error("FETCH RESTAURANT ID BY USER ERROR:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
});
export default router;
