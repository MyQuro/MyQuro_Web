import express from "express";
import cors from "cors";
import { toNodeHandler } from "better-auth/node";
import { auth } from "./auth/auth";
import protectedRoutes from "./routes/protected.routes";
import restaurantRoutes from "./routes/restaurant.routes";
import applyRestaurantRoutes from "./routes/restaurants-apply.routes";
import staffInviteRoutes from "./routes/restaurant-staff.routes";
import staffRequestAcceptRoutes from "./routes/staff-request-accept.routes";
import tableRoutes from "./routes/restaurant-tables.routes";
import menuRoutes from "./routes/menu.routes";
import scanQr from "./routes/qr.routes";
import orders from "./routes/order.routes";
import billingRoutes from "./routes/billing.routes";
import paymentsRoutes from "./routes/payments.routes";
import profileRoutes from "./routes/profile.routes";

export const app = express();

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:3000",
    credentials: true,
  })
);
app.use(express.json());
app.set("trust proxy", true);

app.get("/", (_req, res) => {
  res.json({ message: "MyQuro Backend API", status: "running" });
});

app.use("/api/auth", toNodeHandler(auth));

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/api/protected", protectedRoutes);
app.use("/api/profile", profileRoutes);

app.use(
  "/api/restaurants",
  applyRestaurantRoutes,
  restaurantRoutes,
  staffInviteRoutes
);
app.use("/api/restaurant-tables", tableRoutes);
app.use("/api/staff-requests", staffRequestAcceptRoutes);
app.use("/api/menus", menuRoutes);
app.use("/api/qr", scanQr);
app.use("/api/orders", orders);
app.use("/api/billing", billingRoutes);
app.use("/api/payments", paymentsRoutes);

app.use(
  "/api/admin",
  require("./routes/restaurant-review-request.routes").default
);
