import "dotenv/config";

import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { eq } from "drizzle-orm";

import { db } from "../db/db";

import { authUsers } from "../db/schema/auth-users";
import { authAccounts } from "../db/schema/auth-accounts";
import { authSessions } from "../db/schema/auth-sessions";
import { authVerificationTokens } from "../db/schema/auth-verification-tokens";
import { profiles } from "../db/schema/profiles";

export const auth = betterAuth({
  baseURL: process.env.BETTER_AUTH_URL,
  trustHost: true,
  trustedOrigins: ["http://localhost:4000", "http://localhost:3000"],

  database: drizzleAdapter(db, {
    provider: "pg",
    schema: {
      user: authUsers,
      account: authAccounts,
      session: authSessions,
      verification: authVerificationTokens,
    },
  }),
  user: {
    additionalFields: {
      role: {
        type: "string",
        required: false,
        defaultValue: "customer",
        input: false, // not settable by user input
      },
    },
  },

  // MOVE DATABASE HOOKS HERE (outside of drizzleAdapter)
  databaseHooks: {
    user: {
      create: {
        after: async (user) => {
          // Profile is created automatically after user creation
          console.log("🔍 Database hook - User created:", user.email);

          try {
            const profileId = crypto.randomUUID();

            await db.insert(profiles).values({
              id: profileId,
              userId: user.id,
              username: user.email.split("@")[0] + "_" + Date.now(),
            });

            console.log(
              "✅ Profile auto-created:",
              profileId,
              "for:",
              user.email
            );
          } catch (err) {
            console.error("❌ Profile creation failed:", err);
          }

          return;
        },
      },
    },
  },

  emailAndPassword: {
    enabled: true,
    autoSignIn: true,
    requireEmailVerification: false,
    disableSignUp: false,
  },

  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
  },
});
