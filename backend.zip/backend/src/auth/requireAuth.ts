import { auth } from "./auth";
import { fromNodeHeaders } from "better-auth/node";

interface User {
  [key: string]: any;
}

interface Session {
  user?: User | null;
}

interface RequestWithHeaders {
  headers: Record<string, string | string[] | undefined>;
  user?: User;
}

interface ResponseLike {
  status: (code: number) => {
    json: (body: any) => ResponseLike;
  };
  json?: (body: any) => ResponseLike;
}

type NextFunction = (err?: any) => void;

export const requireAuth = async (
  req: RequestWithHeaders,
  res: ResponseLike,
  next: NextFunction
): Promise<void | ResponseLike> => {
  try {
    // ✅ 1. Verify session
    const session = (await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    })) as Session | null;

    if (!session || !session.user) {
      console.log("No session found");
      return res.status(401).json({ error: "Unauthorized" });
    }

    const user = session.user;
    req.user = user;

    next();
  } catch (err) {
    console.error("❌ Auth middleware error:", err);
    return res.status(401).json({ error: "Invalid session" });
  }
};
